package com.example.customview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv);

        Animation anim = new AlphaAnimation(0.5f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(500);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tv.startAnimation(anim);
    }

    public void viewbutton(View view) {
        Intent i = new Intent(this, Custom_Button.class);
        startActivity(i);
    }

    public void radiobutton(View view) {
        Intent i = new Intent(this, Radio_Button.class);
        startActivity(i);
    }

    public void checkbox(View view) {
        Intent i = new Intent(this, Check_Box.class);
        startActivity(i);
    }
}
