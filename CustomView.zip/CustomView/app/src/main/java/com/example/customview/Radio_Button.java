package com.example.customview;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Radio_Button extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton customradioButton;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.radio_button);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        tv = findViewById(R.id.tv);

        Animation anim = new AlphaAnimation(0.5f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(500);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tv.startAnimation(anim);
    }

    public void onRadioButtonClick(View view) {

        int selectedId = radioGroup.getCheckedRadioButtonId();
        customradioButton = (RadioButton) findViewById(selectedId);
        if(selectedId==-1){
            Toast.makeText(Radio_Button.this,"Nothing selected", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(Radio_Button.this,customradioButton.getText(), Toast.LENGTH_SHORT).show();
        }

    }
}
