package com.example.customview;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Check_Box extends AppCompatActivity {

    TextView tv;
    CheckBox check1, check2, check3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_box);

        tv = findViewById(R.id.tv);
        check1=(CheckBox)findViewById(R.id.check1);
        check2=(CheckBox)findViewById(R.id.check2);
        check3=(CheckBox)findViewById(R.id.check3);


        Animation anim = new AlphaAnimation(0.5f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(500);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tv.startAnimation(anim);
    }

    public void checkClick(View view){
        StringBuilder sb=new StringBuilder("");

        if(check1.isChecked()){
            String s1=check1.getText().toString();
            sb.append(s1);
        }

        if(check2.isChecked()){
            String s2=check2.getText().toString();
            sb.append("\n").append(s2);

        }

        if(check3.isChecked()){
            String s3=check3.getText().toString();
            sb.append("\n").append(s3);

        }

        if(!sb.toString().equals("")){
            Toast.makeText(getApplicationContext(), sb, Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(getApplicationContext(),"Nothing Selected", Toast.LENGTH_LONG).show();
        }

    }

}

